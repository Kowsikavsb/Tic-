"""
Run this LOCALLY (not in Claude's sandbox) to fetch and filter the
Customer Support on Twitter dataset down to Uber_Support conversations.

Prereqs:
    pip install kaggle pandas
    Set up your Kaggle API token: https://www.kaggle.com/docs/api
    (place kaggle.json in ~/.kaggle/kaggle.json)

Usage:
    python fetch_uber_support.py

Output:
    uber_support_raw.csv       -- all tweets involving Uber_Support (either side)
    uber_support_threads.csv   -- reconstructed customer->brand->customer reply chains
"""

import pandas as pd
import subprocess
import os
import zipfile

DATASET = "thoughtvector/customer-support-on-twitter"
ZIP_NAME = "customer-support-on-twitter.zip"
CSV_NAME = "twcs/twcs.csv"

def download():
    if not os.path.exists(ZIP_NAME):
        print("Downloading dataset from Kaggle...")
        subprocess.run(
            ["kaggle", "datasets", "download", "-d", DATASET],
            check=True,
        )
    if not os.path.exists("twcs"):
        print("Unzipping...")
        with zipfile.ZipFile(ZIP_NAME, "r") as z:
            z.extractall(".")

def filter_and_save():
    print("Loading full CSV (this is the only slow, memory-heavy step)...")
    df = pd.read_csv(CSV_NAME)

    # Rows where Uber_Support is either the author or is mentioned by the author
    is_uber = (df["author_id"] == "Uber_Support") | (
        df["text"].str.contains("@Uber_Support", case=False, na=False)
    )
    uber_df = df[is_uber].copy()
    print(f"Found {len(uber_df)} rows involving Uber_Support")
    uber_df.to_csv("uber_support_raw.csv", index=False)

    # Reconstruct threads: for every Uber_Support reply, walk back via
    # in_response_to_tweet_id to get the customer message(s) it answers,
    # and forward to get the customer's follow-up (if any).
    all_df = df.set_index("tweet_id", drop=False)
    brand_replies = uber_df[uber_df["author_id"] == "Uber_Support"]

    records = []
    for _, reply in brand_replies.iterrows():
        parent_id = reply.get("in_response_to_tweet_id")
        if pd.isna(parent_id):
            continue
        parent_id = int(parent_id) if str(parent_id).strip() else None
        if parent_id not in all_df.index:
            continue
        customer_msg = all_df.loc[parent_id]
        if customer_msg["author_id"] == "Uber_Support":
            continue  # skip brand-to-brand chains

        # Look for the customer's follow-up to this brand reply, if any
        followup_mask = all_df["in_response_to_tweet_id"] == reply["tweet_id"]
        followups = all_df[followup_mask]
        followup_text = followups.iloc[0]["text"] if len(followups) else None

        records.append({
            "customer_tweet_id": customer_msg["tweet_id"],
            "customer_text": customer_msg["text"],
            "customer_created_at": customer_msg["created_at"],
            "brand_tweet_id": reply["tweet_id"],
            "brand_text": reply["text"],
            "brand_created_at": reply["created_at"],
            "customer_followup_text": followup_text,
        })

    threads_df = pd.DataFrame(records)
    threads_df.to_csv("uber_support_threads.csv", index=False)
    print(f"Saved {len(threads_df)} reconstructed threads to uber_support_threads.csv")
    print(f"Saved {len(uber_df)} raw rows to uber_support_raw.csv")
    print("\nUpload BOTH files back to Claude (uber_support_threads.csv is the important one).")

if __name__ == "__main__":
    download()
    filter_and_save()
