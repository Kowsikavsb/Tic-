# Decision Log

Non-obvious decisions made while building this, and why. Bullet points, as requested.

1. **Intent taxonomy is a hypothesis, not a discovery.** `src/taxonomy.py`'s
   9 intents were drafted from domain knowledge of what Uber support
   traffic looks like, *before* systematically reading a sample of real
   messages. This is explicitly flagged in that file's docstring. The
   right process is open-coding ~50-100 real messages first and letting
   categories emerge, then formalizing — I did it in the faster,
   riskier order and I'm flagging the risk rather than hiding it. (If
   time allowed, this would be redone properly first.)

2. **Golden-set sampling is stratified + oversampled on purpose, not
   uniform random.** Pure random sampling from a real support corpus is
   dominated by routine, low-stakes messages, which would make the
   escalation-precision metric (the one that matters most, see README)
   nearly untestable — there'd be too few true-escalate examples to get
   a meaningful recall estimate. So the sampler deliberately oversamples
   messages with safety/money keywords. This means **the golden set's
   class balance does not reflect the true incoming traffic distribution**
   — a fact that belongs in the "what's misleading about my headline
   number" section, not buried in a script docstring.

3. **Escalation ground truth is a judgment call, not a fact.** Unlike
   intent (which has a mostly-correct answer), "should this have been
   escalated" is itself a policy decision a real human labeler is making
   on Uber's behalf. I labeled it myself, alone, which means the ground
   truth carries my own risk tolerance, not Uber's actual one. This is a
   real limitation of a single-labeler golden set, called out explicitly
   rather than presented as ground truth without caveat.

4. **Retrieval grounding uses TF-IDF, not LLM embeddings.** Chosen for
   reproducibility (no API key needed for this step, deterministic across
   runs) and speed (in-process, no network latency), at the cost of
   missing paraphrase-level similarity that embeddings would catch (e.g.
   "car showed up empty" vs "driver never arrived" wouldn't match well
   under TF-IDF). Flagged as a "what I'd do next" item.

5. **Classification and drafting are separate LLM calls, not one
   combined call.** Slightly more expensive (two calls instead of one),
   but keeps the escalation policy's confidence signal cleanly separable
   from generation, and means a classification failure doesn't corrupt
   the draft (or vice versa) — easier to unit test and debug independently.

6. **The pipeline always drafts a reply, even for escalated messages.**
   An escalated message still gets a draft, marked
   `human_review_starting_point` rather than `auto_sendable`, so a human
   agent has something to start from instead of a blank page. This
   doubles LLM drafting cost across escalated messages but was judged
   worth it for a real product; it's a design choice, not a metric-gaming
   move (the eval harness scores it separately from the escalation
   decision itself).

7. **Escalation is a deterministic rule-based policy layered on the
   classifier, not a fourth LLM call.** An LLM judging its own confidence
   is unreliable and unauditable. A rule-based policy composed of
   (a) hard safety-keyword override, (b) unclear-intent override,
   (c) confidence threshold, (d) per-intent policy tier, is fully testable
   with unit tests (see `tests/test_smoke_no_api.py`) and every decision
   has a plain-English reason string attached, which the assignment
   explicitly requires.

8. **A hard-coded safety-keyword override exists independent of
   classifier confidence, and building it surfaced a real bug worth
   documenting rather than quietly fixing.** An early keyword list
   included the bare word "crash", which matched both "car crash" and
   "the app crashed" — force-escalating routine app-technical-issue
   messages as safety incidents. Fixed by requiring more specific phrases
   for ambiguous terms. Kept as a named regression test
   (`test_escalation_no_false_positive_on_app_crash`) and as a failure-mode
   example in the report, because finding-and-fixing-quietly would hide
   exactly the kind of brittleness a reviewer should know about.

9. **The "simple" intent baseline is evaluated via 5-fold cross-validation
   on the golden set itself, not a separately labeled training set.**
   This is a real limitation, not a hidden one: it means the simple
   baseline's number is somewhat optimistic relative to a genuinely
   held-out production baseline, because the golden set is small and the
   same 200 examples are doing double duty as both the baseline's
   training signal (via CV folds) and the pipeline's test set. Flagged in
   `eval/baselines.py`'s docstring and in the report's misleading-numbers
   section.

10. **Escalation baselines include "always escalate" as the trivial
    comparison, not "always auto-handle."** "Always escalate" trivially
    gets perfect escalation recall (it never misses a true escalation)
    while being useless as a product (100% human load) — this is the
    right trivial baseline precisely because it's a reminder that recall
    alone is not a sufficient metric; precision has to be reported
    alongside it or the pipeline looks worse than a useless baseline on
    recall alone.

11. **The LLM judge scores 4 independent axes (grounded, on-brand tone,
    actionable, safe), not one overall 1-5 score.** A single scalar
    hides *why* a reply failed, which is exactly what the failure
    analysis needs. "Grounded" is weighted higher in the pass/fail
    threshold (must be ≥4, others just ≥3) because fabricating specific
    facts (refund amounts, policy claims) is judged more disqualifying
    for a brand-safety agent than a slightly off tone.

12. **Judge-human agreement is measured on a subset (40 examples), not
    the full golden set**, purely because human labeling time is the
    scarce resource. This is called out as a real caveat on the kappa
    estimate's precision — 40 examples gives a directionally meaningful
    but not tightly-bounded kappa.

13. **Text cleaning strips @mentions and URLs before feeding messages to
    the classifier/drafter**, on the theory that the classifier shouldn't
    be able to "cheat" by pattern-matching on the brand handle, and the
    drafter shouldn't echo dead links back to the customer. Tradeoff:
    this also strips information (e.g., a customer @-mentioning a
    specific driver's Twitter handle) that could occasionally be useful
    context; judged a net positive for a first version.

14. **Baseline replies (canned text, verbatim nearest-neighbor retrieval)
    are tracked in `results.csv` but the report treats their judge scores
    with an extra grain of salt** rather than a flat apples-to-apples
    comparison to the LLM-drafted replies — the rubric's "on-brand tone"
    axis is nearly automatically satisfied by verbatim historical replies
    (they *are* the brand's tone, by construction), which would make that
    baseline look artificially strong on that one axis specifically. This
    nuance is spelled out in the report rather than left for the raw
    number to imply something misleading on its own.

15. **The escalation confidence threshold (0.6) is a stated, arbitrary
    starting point, not something tuned on the golden set.** Tuning it on
    the same 200 examples used for the headline metric would inflate the
    reported numbers relative to true generalization. It's picked once,
    up front, documented here, and left alone; the report's "what I'd do
    next" section proposes tuning it properly on a separate validation
    split if more labeled data were available.
