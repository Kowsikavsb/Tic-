# Report — Uber Support AI Agent

*Numbers marked `[FILL IN AFTER run_eval.py]` are placeholders — this report
is written to be completed the moment `eval/metrics_summary.json` exists. See
README for the exact commands. Everything else (framing, methodology,
known failure modes, limitations) is written now because it doesn't
depend on the actual numbers.*

## 1. Problem framing

**What "good" means for this brand.** `Uber_Support` handles high emotional
stakes at low dollar value per interaction (a delayed ride, a rude driver,
a small fare dispute) alongside a long tail of genuinely serious issues
(safety incidents, larger fare disputes, account fraud). For a brand like
this, I'm treating the priority ordering as:

1. **Never auto-handle something that should have gone to a human**
   (escalation *recall* on the true-positive class — missing a safety or
   money issue is the failure that destroys trust and creates real harm).
2. **Don't fabricate specific facts in a reply** (grounding) — an AI
   promising a refund amount or timeline it has no authority over is worse
   than a generic "we'll look into it," because it creates a commitment
   the brand now has to honor or explicitly break.
3. **Correctly classify intent** — useful for routing and for grounding
   replies, but a wrong intent label that still gets escalated correctly
   is a minor inefficiency, not a trust failure.
4. **Escalation precision** (not needlessly routing easy stuff to humans)
   matters for the business case (cost savings) but is explicitly ranked
   below recall — an agent that escalates too much is disappointing; one
   that escalates too little is dangerous.

**What I chose not to build:**
- No multi-turn conversation handling. Each customer message is treated as
  a single incoming item to classify/draft/escalate, using the
  *historical* thread corpus only for retrieval grounding, not for
  tracking an ongoing live conversation's state. A real system needs
  session memory; this is a single-turn triage layer, which is a
  reasonable and common first slice of a support-automation project.
- No actual auto-send integration. "Auto-handle" here means "the pipeline
  is confident enough that a human wouldn't need to intervene," not "this
  reply is wired up to actually post to Twitter." That's an intentionally
  separate, later concern (rate limits, brand legal review of the
  auto-send policy itself, etc.).
- No fine-tuning. Everything is prompted, off-the-shelf `gpt-4o-mini`. A
  fine-tuned classifier would likely be cheaper and possibly more
  accurate at scale but isn't a reasonable one-week deliverable and would
  make the "reproduce in 15 minutes" requirement much harder to satisfy.
- No handling of non-English tweets, images/screenshots attached to
  tweets, or thread branches with multiple customer follow-ups. Out of
  scope for a first version; flagged, not silently dropped.

## 2. Results vs. baselines

Full methodology in `eval/baselines.py` and `eval/run_eval.py`.
See `decision_log.md` #9-10 for why these specific baselines were chosen.

| Task | Metric | Trivial baseline | Simple baseline | Full pipeline |
|---|---|---|---|---|
| Intent classification | Accuracy | `[FILL IN]` (most-frequent-class) | `[FILL IN]` (TF-IDF+LogReg, 5-fold CV) | `[FILL IN]` |
| Intent classification | Macro F1 | `[FILL IN]` | `[FILL IN]` | `[FILL IN]` |
| Escalation decision | Precision | `[FILL IN]` (always-escalate) | `[FILL IN]` (keyword rule) | `[FILL IN]` |
| Escalation decision | Recall | `[FILL IN]` (=1.0 by construction) | `[FILL IN]` | `[FILL IN]` |
| Escalation decision | F1 | `[FILL IN]` | `[FILL IN]` | `[FILL IN]` |
| Reply quality | LLM-judge pass rate | n/a (canned reply judged separately, see decision_log #14) | `[FILL IN]` | `[FILL IN]` |

**How to read the escalation row honestly:** "always escalate" gets
recall=1.0 trivially and should not be read as a competitive baseline —
it's there specifically so the pipeline's recall number has to be
interpreted next to its precision, not admired alone. The pipeline's
value proposition is maintaining recall close to that trivial ceiling
*while* getting real precision (i.e., not sending everything to a human).

## 3. Failure analysis (top 5, to be filled in from real `results.csv` /
`intent_confusion_matrix.csv` once available — structure and one confirmed
example below)

1. **Ambiguous multi-intent messages** (hypothesis, confirm against
   confusion matrix): a message like "driver was late AND rude AND I want
   a refund" plausibly gets split-decision votes between
   `driver_behavior_complaint` and `trip_fare_dispute`. Hypothesis: the
   classifier picks whichever issue is mentioned first/last inconsistently.
   *Fix direction:* allow multi-label classification, or an explicit
   tie-breaking rule (more specific complaint wins, per the labeling
   guide's own instruction to labelers — meaning the model should follow
   the same rule the humans were told to follow).

2. **Confirmed bug — ambiguous safety keywords causing false escalation
   overrides.** Found during development: the bare keyword `"crash"` in
   the safety override matched both "car crash" and "the app crashed",
   force-escalating routine `app_technical_issue` messages. See
   `decision_log.md` #8 and the regression test
   `test_escalation_no_false_positive_on_app_crash`. This is a real,
   caught-in-development example of the general risk in keyword-based
   safety nets: **precision on keyword triggers degrades fast with
   polysemous words**, and this exact category of bug should be assumed
   to have surviving instances elsewhere in the list (e.g. does "hit"
   only match "hit my car" as intended, or could "that joke really hit"
   theoretically false-positive? — worth an explicit audit pass).

3. **Retrieval grounding quality on paraphrased complaints** (hypothesis):
   TF-IDF retrieval (decision_log #4) is lexical, not semantic. A message
   like "the driver never showed up" and a historical case phrased "car
   was a no-show" share zero non-stopword tokens and would retrieve
   poorly, so the draft would fall back to generic brand tone without a
   good grounding example. *Fix direction:* swap in embeddings, or at
   minimum expand the query with synonyms before TF-IDF matching.

4. **Golden-set label noise from single-labeler ground truth**
   (structural, not a pipeline failure): any case where the pipeline
   disagrees with the golden label is being scored as a pipeline error,
   but some fraction of those disagreements are probably labeler error
   or genuinely ambiguous judgment calls (decision_log #3). Without a
   second labeler's overlap, this can't be separated from real model
   error in the current numbers — flagged, not resolved.

5. **`[FILL IN after inspecting results.csv]`** — pull the specific
   examples where `judge_grounded <= 2` (the drafter stated something
   as fact that isn't supported) and quote 1-2 verbatim, since fabrication
   is the highest-priority failure mode per the problem framing in §1.

## 4. What is misleading about my headline number

This section is mandatory and I'm taking it at face value: here is
specifically how a reader could over-trust the numbers above.

- **The golden set is not representative of real incoming traffic.**
  It's stratified and oversampled toward safety/money keywords on purpose
  (decision_log #2), which means the escalation-recall number is measured
  on a set that contains *more* of the hard, should-escalate cases than
  Uber's actual message stream would. A production system's true
  escalation rate would very likely be different (probably lower, since
  most real traffic is more mundane than this sample) — this eval set is
  built to stress-test the risky tail, not to estimate real-world
  auto-handle percentage. **Do not quote "the model auto-handles X% of
  messages" from these numbers** — that requires a separate, unbiased
  traffic-representative sample.

- **Escalation "ground truth" is one person's judgment call, not an
  objective fact**, and that person (me) built the system being
  evaluated — an obvious incentive/blind-spot risk even when done in
  good faith. A kappa between two independent labelers would be the real
  test of whether "should escalate" is even a well-defined label; we
  don't have that here (decision_log #3, #12 partial mitigation via
  judge-agreement work but that's for reply quality, not escalation
  ground truth itself).

- **The "simple" intent baseline's number is inflated relative to a real
  production baseline** because it's cross-validated on the same 200
  golden examples the full pipeline is tested on (decision_log #9), not
  trained on an independent, larger labeled set the way a real "simple
  baseline you'd ship" would be. The gap between it and the full pipeline
  may be smaller here than it would be at real scale, or larger — it's
  genuinely unclear which direction the bias runs, which is itself worth
  saying rather than picking the flattering interpretation.

- **The LLM judge is not a neutral third party** — it's the same
  underlying model family as the one being judged, prompted with a rubric
  I wrote to reflect the priorities in §1. `eval/judge_agreement.py`'s
  kappa is the actual evidence for whether to trust it, and it's measured
  on only 40 examples (decision_log #12) — a small enough sample that the
  kappa estimate itself has real uncertainty. A kappa in the "moderate"
  range should be read as "this judge is a useful triage signal, not a
  substitute for human QA," not as validation that the judge is right.

- **Pass rate is not the same as "safe to deploy."** A judge pass rate of
  even 90%+ still means roughly 1 in 10 auto-eligible replies has some
  flaw the judge caught — and judge misses (false negatives on quality)
  aren't captured by pass rate at all. The right way to read the headline
  reply-quality number is as a *relative* comparison to baselines, not an
  absolute deployment-readiness bar.

## 5. What I'd do next with one more week

1. **Redo the taxonomy properly**: open-code 100-150 real messages first,
   let categories emerge, then reconcile with the current 9-intent
   hypothesis rather than the reverse order used here (decision_log #1).
2. **Second labeler on the golden set** (even 50-example overlap) to get
   a real inter-labeler kappa on both intent and escalation ground truth
   — this is the single highest-value next step for trusting the whole
   eval, because everything else is measured against this ground truth.
3. **Swap TF-IDF retrieval for embeddings** and re-run the paraphrase
   failure mode (§3.3) as a direct A/B on retrieval quality, not just a
   hypothesis.
4. **Expand the golden set to include a traffic-representative random
   sample as a *second*, separate eval slice**, explicitly to get an
   honest estimate of real-world auto-handle rate — keeping the current
   stress-test sample as-is rather than replacing it, since both answer
   different questions (§4's first bullet).
5. **Audit the full safety-keyword list** for other polysemous false
   positives like the "crash" bug (§3.2), ideally by running it against a
   larger unlabeled sample and manually reviewing every trigger.
6. **Tune the 0.6 confidence threshold properly** on a held-out
   validation split rather than leaving it as an untuned starting point
   (decision_log #15).
7. **Try fine-tuning a small classifier** on a larger labeled set once
   one exists, and compare cost/latency/accuracy against the
   prompted-`gpt-4o-mini` approach at production scale.
